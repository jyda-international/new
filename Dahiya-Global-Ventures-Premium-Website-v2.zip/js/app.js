
window.addEventListener("load",()=>document.documentElement.classList.add("loaded"));
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add("show")}),{threshold:.1});
document.querySelectorAll(".reveal").forEach(e=>io.observe(e));
